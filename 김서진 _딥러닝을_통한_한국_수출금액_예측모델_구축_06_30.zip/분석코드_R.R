library(readxl)
data <- read_excel("C:/������/data.xlsx", sheet = "2. raw data")
View(data)
head(data)
library(tseries)
library(forecast)
data.ts=ts(data)
data.ts
plot.ts(data.ts)

library(fUnitRoots)
adfTest(data.ts[,2])
adfTest(data.ts[,3])
adfTest(data.ts[,4])
adfTest(data.ts[,5])
adfTest(data.ts[,6])
adfTest(data.ts[,7])

imsi = ts(data, frequency = 12)
imsi.2 = decompose(imsi[,2],"additive")
imsi.3 = decompose(imsi[,3],"additive")
imsi.4 = decompose(imsi[,4],"additive")
imsi.5 = decompose(imsi[,5],"additive")
imsi.6 = decompose(imsi[,6],"additive")
imsi.7 = decompose(imsi[,7],"additive")
plot(imsi.2) #�߼�, ������
plot(imsi.3) #�߼�, ������
plot(imsi.4) #�߼�, ������, �л����ȭ
plot(imsi.5) #�߼�, ������, �л����ȭ
plot(imsi.6) #�߼�, ������
plot(imsi.7) #�߼�, ������

diff2 = diff(imsi[,2], lag=1)
diff22 = diff(diff2, lag=12)
plot(diff2)
plot(diff22)

diff3 = diff(imsi[,3], lag=1)
diff33 = diff(diff3, lag=12)
plot(diff3)
plot(diff33) 

log4 = log(imsi[,4])
diff4 = diff(log4, lag=1)
diff44 = diff(diff4, lag=12)
plot(diff4)
plot(diff44)

log5 = log(imsi[,5])
diff5 = diff(log5, lag=1)
diff55 = diff(diff5, lag=12)
plot(diff5)
plot(diff55)

diff6 = diff(imsi[,6], lag=1)
diff66 = diff(diff6, lag=12)
plot(diff6)
plot(diff66)

diff7 = diff(imsi[,7], lag=1)
diff77 = diff(diff7, lag=12)
plot(diff7)
plot(diff77)

diffdata = cbind(diff22, diff33, diff44, diff55, diff66, diff77)




library(lmtest)
grangertest(diff22~diff33, order=2,data=diffdata)
grangertest(diff22~diff44, order=2,data=diffdata)
grangertest(diff22~diff55, order=2,data=diffdata)  #
grangertest(diff22~diff66, order=2,data=diffdata)
grangertest(diff22~diff77, order=2,data=diffdata)  #

use_data = cbind(diff22, diff33, diff44, diff66)
use_data

fit_data = cbind(imsi[,2], imsi[,3], imsi[,4], imsi[,6])
fit_data

library(vars)
VARselect(use_data) #p=2
var.1 = VAR(fit_data, p=2, type="none")

pred = predict(var.1, n.ahead=6, ci=0.95)
result = pred$fcst$imsi...2.[,1]

