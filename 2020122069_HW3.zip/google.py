import math
import torch
import torchcde
import sklearn.model_selection

from random import SystemRandom
import random
import numpy as np 
from parse import parse_args
import pathlib
import os 
import time 
import tqdm
import torchdiffeq
import matplotlib.pyplot as plt
args = parse_args()

def split_data(tensor, stratify):
    
    (train_tensor, testval_tensor,
     train_stratify, testval_stratify) = sklearn.model_selection.train_test_split(tensor, stratify,
                                                                                  train_size=0.7,
                                                                                  random_state=0,
                                                                                  shuffle=True,
                                                                                  stratify=stratify)

    val_tensor, test_tensor = sklearn.model_selection.train_test_split(testval_tensor,
                                                                       train_size=0.5,
                                                                       random_state=1,
                                                                       shuffle=True,
                                                                       stratify=testval_stratify)
    return train_tensor, val_tensor, test_tensor
def normalise_data(X,y):
    
    train_X, _, _ = split_data(X, y) 
    out = []
    for Xi, train_Xi in zip(X.unbind(dim=-1), train_X.unbind(dim=-1)):
        train_Xi_nonan = train_Xi.masked_select(~torch.isnan(train_Xi))
        mean = train_Xi_nonan.mean()  
        std = train_Xi_nonan.std()
        out.append((Xi - mean) / (std + 1e-5))
    out = torch.stack(out, dim=-1)
    return out


class _GRU_forecasting(torch.nn.Module):
    def __init__(self, input_channels, hidden_channels, output_channels, forecast_window,device):
        super(_GRU_forecasting, self).__init__()

        
        self.input_channels = input_channels
        self.hidden_channels = hidden_channels
        self.output_channels = output_channels
        self.forecast_window = forecast_window
        
        self.device = device
        gru_channels = input_channels 
        
        self.gru_cell = torch.nn.GRUCell(input_size=gru_channels, hidden_size=hidden_channels)
        self.readout = torch.nn.Linear(hidden_channels, input_channels-1)
        
    def extra_repr(self):
        return "input_channels={}, hidden_channels={}, output_channels={}" \
               "".format(self.input_channels, self.hidden_channels, self.output_channels)

    def evolve(self, h, time_diff):
        raise NotImplementedError

    def _step(self, Xi, h, dt, half_num_channels):
        
        observation = Xi[:, 1: 1 + half_num_channels].max(dim=1).values > 0.5
        if observation.any():
            Xi_piece = Xi 
            Xi_piece = Xi_piece.clone() 
            Xi_piece[:, 0] += dt
            new_h = self.gru_cell(Xi_piece.float(), h.float()) 
            h = torch.where(observation.unsqueeze(1), new_h, h)
            dt += torch.where(observation, torch.tensor(0., dtype=Xi.dtype, device=Xi.device), Xi[:, 0])
        return h, dt

    def forward(self, coeffs,times, z0=None):
        
        # interpolation
        XX = torchcde.CubicSpline(coeffs)
        times = torch.Tensor(np.arange(XX.interval[-1].item())).to(self.device)
        X = torch.stack([XX.evaluate(t) for t in times], dim=-2) 
        half_num_channels = (self.input_channels - 1) // 2

        X[:, 1:, 1:1 + half_num_channels] -= X[:, :-1, 1:1 + half_num_channels]

        X[:, 0, 0] -= times[0]
        X[:, 1:, 0] -= times[:-1]

        batch_dims = X.shape[:-2]

        if z0 is None:
            z0 = torch.zeros(*batch_dims, self.hidden_channels, dtype=X.dtype, device=X.device)
        
        X_unbound = X.unbind(dim=1)
        
        h, dt = self._step(X_unbound[0].float(), z0.float(), torch.zeros(*batch_dims, dtype=X.dtype, device=X.device).float(),
                           half_num_channels)
        hs = [h]
        time_diffs = times[1:] - times[:-1]
        for time_diff, Xi in zip(time_diffs, X_unbound[1:]):
            h = self.evolve(h, time_diff)
            h, dt = self._step(Xi, h, dt, half_num_channels)
            hs.append(h)
        out = torch.stack(hs, dim=1)
        input_time = out.shape[1]
        out = self.readout(out[:,input_time-self.forecast_window:,:])
        
        return out

class GRU_D_forecasting(_GRU_forecasting):
    def __init__(self, input_channels, hidden_channels, output_channels,forecast_window,device ):
        super(GRU_D_forecasting, self).__init__(input_channels=input_channels,
                                    
                                    hidden_channels=hidden_channels,
                                    output_channels=output_channels,
                                    forecast_window = forecast_window,
                                    device=device)
        self.decay = torch.nn.Linear(1, hidden_channels)

    def evolve(self, h, time_diff):
        return h * torch.exp(-self.decay(time_diff.unsqueeze(0)).squeeze(0).relu())

def main(model_name=args.model,num_epochs=args.epoch):
    
    manual_seed = args.seed
    
    time_intensity=True
    batch_size=256
    np.random.seed(manual_seed)
    random.seed(manual_seed)
    torch.manual_seed(manual_seed)

    torch.cuda.manual_seed(manual_seed)
    torch.cuda.manual_seed_all(manual_seed)
    torch.random.manual_seed(manual_seed)
    print(f"Setting of this Experiments{args}")
    device="cuda"
    
    
    look_window = 20
    forecast_window=10
    stride_window = 2
    missing_rate = 0.3
    
    here = pathlib.Path(__file__).resolve().parent
    base_base_loc = here / '/content/drive/MyDrive/HW3/code&data/datasets/processed_data'
    loc = base_base_loc / ('Stock_' +str(look_window)+'_'+str(forecast_window)+'_'+str(missing_rate))
    if args.interpolation=='natural_cubic':
        coeff_loc = loc / ('NaturalCoeffs')
    else:    
        coeff_loc = loc / ('Coeffs')
    
    times        = torch.load(str(loc)+'/times.pt')
   
    train_y       =  torch.load(str(loc) +'/train_y_seq_data.pt')
    val_y       =  torch.load(str(loc) +'/val_y_seq_data.pt')
    test_y       =  torch.load(str(loc) +'/test_y_seq_data.pt')
    
    
    train_X = torch.load(str(loc) +'/train_seq_data.pt')
    val_X = torch.load(str(loc) +'/val_seq_data.pt')
    test_X = torch.load(str(loc) +'/test_seq_data.pt')
    
    
    augmented_train_X = []
    if time_intensity:
        augmented_train_X.append(times.unsqueeze(0).repeat(train_X.size(0), 1).unsqueeze(-1))
    
    augmented_train_X.append(train_X)
    if len(augmented_train_X) == 1:
        train_X = augmented_train_X[0]
    else:
        train_X = torch.cat(augmented_train_X, dim=2)
    
    augmented_val_X = []
    if time_intensity:
        augmented_val_X.append(times.unsqueeze(0).repeat(val_X.size(0), 1).unsqueeze(-1))
    
    augmented_val_X.append(val_X)
    if len(augmented_val_X) == 1:
        val_X = augmented_val_X[0]
    else:
        val_X = torch.cat(augmented_val_X, dim=2)
    
    augmented_test_X = []
    if time_intensity:
        augmented_test_X.append(times.unsqueeze(0).repeat(test_X.size(0), 1).unsqueeze(-1))
    
    augmented_test_X.append(test_X)
    if len(augmented_test_X) == 1:
        test_X = augmented_test_X[0]
    else:
        test_X = torch.cat(augmented_test_X, dim=2)

    input_channels = train_X.shape[-1]
    
    train_coeffs = torch.load(str(coeff_loc)+'/train_coeffs.pt')
    val_coeffs = torch.load(str(coeff_loc)+'/val_coeffs.pt')
    test_coeffs = torch.load(str(coeff_loc)+'/test_coeffs.pt')
    
    
    train_coeffs=train_coeffs.to(device)
    val_coeffs=val_coeffs.to(device)
    test_coeffs=test_coeffs.to(device)

    train_y = torch.Tensor(np.nan_to_num(np.array(train_y.cpu())))
    train_y = train_y.to(device)
    val_y = torch.Tensor(np.nan_to_num(np.array(val_y.cpu())))
    val_y = val_y.to(device)
    test_y = torch.Tensor(np.nan_to_num(np.array(test_y.cpu())))
    test_y = test_y.to(device)
    times = times.to(device)
    
    output_channels = train_y.shape[-1]
    hidden_channels=args.h_channels
    hidden_hidden_channels=args.h_channels
    num_hidden_layers=4

    train_dataset = torch.utils.data.TensorDataset(train_coeffs, train_y)
    train_dataloader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size)
    val_dataset = torch.utils.data.TensorDataset(val_coeffs, val_y)
    val_dataloader = torch.utils.data.DataLoader(val_dataset, batch_size=val_y.shape[0])
    test_dataset = torch.utils.data.TensorDataset(test_coeffs, test_y)
    test_dataloader = torch.utils.data.DataLoader(test_dataset, batch_size=test_y.shape[0])
    
    if model_name =='gru_d':
        model = GRU_D_forecasting(input_channels=input_channels, hidden_channels=hidden_channels,
                                 output_channels=output_channels, forecast_window=forecast_window,device=device)
    if model_name =='gru_dd':
        model = GRU_D_double(input_channels=input_channels, hidden_channels=hidden_channels,
                                 output_channels=output_channels, forecast_window=forecast_window,device=device)
    
    if model_name =='odernn':
        model = ODERNN_forecasting(input_channels=input_channels, hidden_channels=hidden_channels, 
        hidden_hidden_channels=hidden_hidden_channels,
                                 output_channels=output_channels, num_hidden_layers=num_hidden_layers,
                                 forecast_window=forecast_window, device=device)
           
    model=model.to(device)
    times=times.to(device)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay = args.weight_decay)
    best_val_mse=np.inf
    loss_fn = torch.nn.MSELoss()
    best_test_epoch = 0
    plateau_terminate = 20
    best_train_loss_epoch=0
    breaking=False
    best_train_mse = np.inf
    tqdm_range = tqdm.tqdm(range(num_epochs))
    tqdm_range.write('Starting training for model:\n\n' + str(model) + '\n\n')
    if device != 'cpu':
        torch.cuda.reset_max_memory_allocated(device)
        baseline_memory = torch.cuda.memory_allocated(device)
    else:
        baseline_memory = None   
    
    train_list = []
    val_list = []
    for epoch in tqdm_range:
        if breaking:
            break
        model.train()
        
        start_time= time.time()
        total_dataset_size = 0
        train_mse=0
        for batch in train_dataloader:
            batch_coeffs, batch_y = batch
            
            pred_y = model(batch_coeffs,times)
            
            b_size = batch_y.size(0)

            loss = loss_fn(pred_y,batch_y)
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            total_dataset_size += b_size
            train_mse += loss * b_size
        train_mse /= total_dataset_size    
        if train_mse * 1.0001 < best_train_mse:
            best_train_mse = train_mse
            best_train_loss_epoch = epoch       
        train_list.append(train_mse)
        print('Epoch: {}  Training MSE: {}, Time :{}'.format(epoch,train_mse,(time.time()-start_time)))
        
        model.eval()
        
        start_time= time.time()
        total_dataset_size = 0
        val_mse=0
        for batch in val_dataloader:
            
            batch_coeffs, batch_y = batch
            
            pred_y = model(batch_coeffs,times)
            
                
            b_size = batch_y.size(0)
            loss = loss_fn(pred_y,batch_y)
            total_dataset_size +=b_size
            val_mse += loss * b_size
        val_mse /= total_dataset_size    
        val_list.append(val_mse)
    
        print('Epoch: {}   Validation MSE: {}, Time :{}'.format(epoch, val_mse,(time.time()-start_time)))
            
        if val_mse<best_val_mse:
            best_val_mse=val_mse
            start_time= time.time()
            total_dataset_size = 0
            test_mse=0
            for batch in test_dataloader:
                batch_coeffs, batch_y = batch
                
                pred_y = model(batch_coeffs,times)
                
                b_size = batch_y.size(0)
                loss = loss_fn(pred_y,batch_y)
                total_dataset_size +=b_size
                test_mse += loss * b_size
            test_mse /= total_dataset_size   
            best_test_epoch = epoch
            
            print('Epoch: {}   Best Test MSE: {}, Time :{}\n'.format(epoch, test_mse,(time.time()-start_time)))
            if epoch > best_train_loss_epoch + plateau_terminate:
                tqdm_range.write('Breaking because of no improvement in training loss for {} epochs.'
                                    ''.format(plateau_terminate))
                breaking = True
            
    memory_usage = torch.cuda.max_memory_allocated(device) - baseline_memory
    print(f"memory_usage:{memory_usage}")
    print('Epoch: {}   Best Test MSE: {}, Time :{}\n'.format(best_test_epoch, test_mse,(time.time()-start_time)))
    
if __name__ == '__main__':
    main()